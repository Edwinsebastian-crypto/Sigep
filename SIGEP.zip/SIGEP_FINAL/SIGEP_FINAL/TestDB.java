import com.mycompany.proyect.modelado.ConexionBD;
import java.sql.Connection;
import java.sql.Statement;

public class TestDB {
    public static void main(String[] args) {
        try {
            Connection conn = ConexionBD.getInstancia().getConexion();
            Statement stmt = conn.createStatement();
            try {
                stmt.execute("ALTER TABLE evidenciabitacora ADD (NombreArchivo VARCHAR2(255), Descripcion VARCHAR2(4000))");
                System.out.println("Columnas agregadas con exito");
            } catch(Exception e) {
                System.out.println("Error o ya existen: " + e.getMessage());
            }
            conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
