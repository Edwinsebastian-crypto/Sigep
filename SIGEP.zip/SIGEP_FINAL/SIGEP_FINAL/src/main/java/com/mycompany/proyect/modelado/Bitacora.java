package com.mycompany.proyect.modelado;

import java.sql.Date;

/**
 * Modelo Bitacora — incluye archivo BLOB, nombreArchivo y descripcion.
 *
 * IMPORTANTE: Estos campos ahora se guardan en la tabla evidenciabitacora:
 *   ALTER TABLE evidenciabitacora ADD (NombreArchivo VARCHAR2(255), Descripcion VARCHAR2(4000));
 */
public class Bitacora {
    private String idBitacora;
    private Date   fechaCreacion;
    private double notaFinal;
    private String observacionFinal;
    private String numDocumento;
    private String idPractica;
    // Columnas nuevas
    private byte[] archivo;
    private String nombreArchivo;
    private String descripcion;

    public Bitacora() {}

    public Bitacora(String idBitacora, Date fechaCreacion, double notaFinal,
                    String observacionFinal, String numDocumento, String idPractica) {
        this.idBitacora       = idBitacora;
        this.fechaCreacion    = fechaCreacion;
        this.notaFinal        = notaFinal;
        this.observacionFinal = observacionFinal;
        this.numDocumento     = numDocumento;
        this.idPractica       = idPractica;
    }

    public String getIdBitacora()           { return idBitacora; }
    public void   setIdBitacora(String v)   { this.idBitacora = v; }
    public Date   getFechaCreacion()        { return fechaCreacion; }
    public void   setFechaCreacion(Date v)  { this.fechaCreacion = v; }
    public double getNotaFinal()            { return notaFinal; }
    public void   setNotaFinal(double v)    { this.notaFinal = v; }
    public String getObservacionFinal()     { return observacionFinal; }
    public void   setObservacionFinal(String v) { this.observacionFinal = v; }
    public String getNumDocumento()         { return numDocumento; }
    public void   setNumDocumento(String v) { this.numDocumento = v; }
    public String getIdPractica()           { return idPractica; }
    public void   setIdPractica(String v)   { this.idPractica = v; }
    public byte[] getArchivo()              { return archivo; }
    public void   setArchivo(byte[] v)      { this.archivo = v; }
    public String getNombreArchivo()        { return nombreArchivo; }
    public void   setNombreArchivo(String v){ this.nombreArchivo = v; }
    public String getDescripcion()          { return descripcion; }
    public void   setDescripcion(String v)  { this.descripcion = v; }

    @Override
    public String toString() {
        return "Bitacora{id='" + idBitacora + "', nota=" + notaFinal + "'}";
    }
}
