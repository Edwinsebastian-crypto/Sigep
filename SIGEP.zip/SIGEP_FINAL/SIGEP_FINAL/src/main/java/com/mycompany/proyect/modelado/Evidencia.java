package com.mycompany.proyect.modelado;

public class Evidencia {
    private String idEvidencia;
    private byte[] archivo;
    private String idBitacora;
    private String nombreArchivo;
    private String descripcion;

    public Evidencia() {}

    public Evidencia(String idEvidencia, byte[] archivo, String idBitacora, String nombreArchivo, String descripcion) {
        this.idEvidencia = idEvidencia;
        this.archivo = archivo;
        this.idBitacora = idBitacora;
        this.nombreArchivo = nombreArchivo;
        this.descripcion = descripcion;
    }

    public String getIdEvidencia() { return idEvidencia; }
    public void setIdEvidencia(String idEvidencia) { this.idEvidencia = idEvidencia; }
    public byte[] getArchivo() { return archivo; }
    public void setArchivo(byte[] archivo) { this.archivo = archivo; }
    public String getIdBitacora() { return idBitacora; }
    public void setIdBitacora(String idBitacora) { this.idBitacora = idBitacora; }
    public String getNombreArchivo() { return nombreArchivo; }
    public void setNombreArchivo(String nombreArchivo) { this.nombreArchivo = nombreArchivo; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
