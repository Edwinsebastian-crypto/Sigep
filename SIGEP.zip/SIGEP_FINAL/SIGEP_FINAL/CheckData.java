import java.sql.*;

public class CheckData {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String user = "PROYECTOSIGEP";
        String pass = "PROYECTOSIGEP";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            
            System.out.println("--- Estudiantes ---");
            ResultSet rs = stmt.executeQuery("SELECT Numdocumento, Nombre, Idpractica FROM Estudiante");
            while (rs.next()) {
                System.out.println("Doc: " + rs.getString(1) + ", Name: " + rs.getString(2) + ", Practica: " + rs.getString(3));
            }
            
            System.out.println("\n--- Practicas ---");
            rs = stmt.executeQuery("SELECT Idpractica, NumDocTutor FROM Practica");
            while (rs.next()) {
                System.out.println("ID: " + rs.getString(1) + ", Tutor: " + rs.getString(2));
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
