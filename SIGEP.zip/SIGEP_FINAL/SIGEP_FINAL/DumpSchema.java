import java.sql.*;

public class DumpSchema {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String user = "PROYECTOSIGEP";
        String pass = "PROYECTOSIGEP";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, user, pass);
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet tables = metaData.getTables(null, "PROYECTOSIGEP", "%", new String[] {"TABLE"});

            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                System.out.println("Table: " + tableName);
                ResultSet columns = metaData.getColumns(null, "PROYECTOSIGEP", tableName, "%");
                while (columns.next()) {
                    String columnName = columns.getString("COLUMN_NAME");
                    String typeName = columns.getString("TYPE_NAME");
                    int columnSize = columns.getInt("COLUMN_SIZE");
                    System.out.println("  - " + columnName + " (" + typeName + ", " + columnSize + ")");
                }
                System.out.println();
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
